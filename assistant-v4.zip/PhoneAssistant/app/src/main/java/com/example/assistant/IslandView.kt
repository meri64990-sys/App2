package com.example.assistant

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.sin

/** Чёрная «капсула» у фронтальной камеры: растёт из точки, показывает волну голоса и текст. */
class IslandView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Color.parseColor("#7C8CFF")
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C8CFF"); strokeWidth = 4 * d; strokeCap = Paint.Cap.ROUND
    }
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 15 * d }

    var text = ""
        set(v) { field = v; invalidate() }
    var level = 0f
    private var open = 0f
    private var phase = 0f

    private val loop = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    private fun animateTo(to: Float, ms: Long, ip: TimeInterpolator, end: (() -> Unit)? = null) {
        ValueAnimator.ofFloat(open, to).apply {
            duration = ms; interpolator = ip
            addUpdateListener { open = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { end?.invoke() }
            })
            start()
        }
    }

    fun expand() { loop.start(); animateTo(1f, 450, OvershootInterpolator(1.4f)) }
    fun collapse(end: () -> Unit) { animateTo(0f, 300, AccelerateInterpolator()) { loop.cancel(); end() } }

    override fun onDraw(c: Canvas) {
        val minS = 34 * d
        val fullW = width - 8 * d
        val fullH = 52 * d
        val w = minS + (fullW - minS) * open
        val h = minS + (fullH - minS) * open
        val l = (width - w) / 2
        val r = RectF(l, 4 * d, l + w, 4 * d + h)
        c.drawRoundRect(r, h / 2, h / 2, bg)
        glow.alpha = (60 + 150 * level).toInt().coerceIn(0, 255)
        c.drawRoundRect(r, h / 2, h / 2, glow)

        val a = ((open - 0.55f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return
        bar.alpha = (255 * a).toInt(); txt.alpha = (255 * a).toInt()
        val amp = 0.25f + 0.75f * level
        for (i in 0 until 5) {
            val hh = (6 + 16 * amp * (0.5f + 0.5f * sin(phase + i * 0.9f))) * d
            val x = r.left + 26 * d + i * 9 * d
            c.drawLine(x, r.centerY() - hh / 2, x, r.centerY() + hh / 2, bar)
        }
        val tx = r.left + 26 * d + 5 * 9 * d + 8 * d
        val s = TextUtils.ellipsize(text, txt, r.right - tx - 20 * d, TextUtils.TruncateAt.END).toString()
        c.drawText(s, tx, r.centerY() - (txt.ascent() + txt.descent()) / 2, txt)
    }
}
